<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Employee;
use App\User;
use Auth;
use Hash;

class AdminController extends Controller
{

   public function adminLogin(){
       return view('admin.adminLogin');
   }

   public function signIn(Request $request){
 $input = $request->all();
        $email = $input['email'];
        $password = trim($input['password']);

        if (Auth::attempt(['email' => $email, 'password' => $password])) {       
          
                setcookie('email', $email, time() + (2592000), "/");
                setcookie('password', base64_encode($password), time() + (2592000), "/");
             
                return redirect('admin/dashboard'); 
                   
        } else {
            return redirect()->back()->with('error', 'Email or password you entered is incorrect.');
        }
   }

   public function adminDashboard(){
      return view('admin.adminDashboard');
   }


public function saveemployee(Request $request){
 $employee = Employee::where('id', $request->id)->first();
    if (!isset($employee) && $employee == '') {
       $employee= new Employee;
    } 
 $employee->name=$request->name;
 $employee->email= $request->email;
 $employee->mobile_no=$request->mobile_no;
 $employee->location=$request->location;
 $employee->save();
 return redirect('admin/view-employee');
}

public function editemployee($id){
     $id = base64_decode($id);    
   $employee = Employee::find($id);
   return view('admin.editEmployee')->with('employee',$employee);
}

public function viewemployee(){

   if (!isset(Auth::user()->id) && !Auth::user() != null) {
            return redirect('admin');
        }
    $user = Employee::all();
    return view('admin.UserList')->with('user', $user);
}

public function deleteEmployee(Request $request)
{
  $id = $request->del_id;
  $employee=Employee::find($id);
  $employee->delete();
  return redirect('admin/view-employee');
}
}

