<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',['uses'=>'HomeController@index'])->name('home');


Route::get('/home',  ['uses'=>'HomeController@dashboard']);

Route::get('/logout',  ['uses'=>'HomeController@logout']);

Route::get('admin', ['uses' => 'AdminController@adminLogin']);
Route::post('admin',['uses' => 'AdminController@signIn']);
Route::get('admin/dashboard', ['uses' => 'AdminController@adminDashboard']);
Route::get('admin/add-employee', ['uses'=>'AdminController@getAddemployee']);
Route::post('admin/add-employee', ['uses'=>'AdminController@saveemployee']);
Route::get('admin/view-employee', ['uses'=>'AdminController@viewemployee']);
Route::get('admin/edit-employee/{id}', ['uses'=>'AdminController@editemployee']);

Route::post('admin/delete-employee', ['uses'=>'AdminController@deleteEmployee']);




