  

  <!-- Start copyright  -->
     <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2020 <a href="#"></a></p>
    </div>
    <!-- End copyright  -->
