@extends('layouts.website')
@section('title', env('APP_NAME'))

@section('content')

  <!-- Start Slider --><!-- Page Content -->
<div class="page-holder bg-cover">

  <div class="container ht">
   
  </div>
</div>
    <!-- End Slider -->

<!-- Start Contact Us  -->
<div class="contact-box-main">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-12">
            
            </div>
            <div class="col-lg-7 col-sm-12"  style="border: 1px solid">
                <div class="contact-form-right">
                    <h2 class="text-center">GET IN TOUCH</h2>

                    <form action="{{url('admin/add-employee')}}" method="post">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" placeholder="Your Email" id="email" class="form-control" name="email" required data-error="Please enter your email">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="mobile_no" name="mobile_no" placeholder="Mobile No" required data-error="Please enter your Mobile no">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                             <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="location" name="location" placeholder="Current location" required data-error="Please enter your Current location">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                              
                                <div class="submit-button text-center">
                                     <input type="hidden" name="_token" id="token" value="{{csrf_token()}}">
                                    <button class="btn hvr-hover" id="submit" type="submit">Send Message</button>
                                    <div id="msgSubmit" class="h3 text-center hidden"></div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Cart -->
@stop


