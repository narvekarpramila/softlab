  

  <!-- Start copyright  -->
     <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2020 <a href="#"></a></p>
    </div>
    <!-- End copyright  -->
<?php /**PATH C:\xampp\htdocs\softlab\resources\views/layouts/website/footer.blade.php ENDPATH**/ ?>