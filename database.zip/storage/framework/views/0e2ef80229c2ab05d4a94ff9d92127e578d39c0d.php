

<?php $__env->startSection('title', env('APP_NAME').' - Dashboard'); ?>

<?php $__env->startSection('header_styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
<!-- Breadcome start-->
<div class="breadcome-area mg-b-30 small-dn">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <div class="breadcome-heading">
                                <form role="search" class="">
                                    <input type="text" placeholder="Search..." class="form-control">
                                    <a href=""><i class="fa fa-search"></i></a>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <ul class="breadcome-menu">
                                <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                </li>
                                <li><span class="bread-blod">Dashboard</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcome End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<!-- Data table area Start-->
<div class="admin-dashone-data-table-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="sparkline8-list shadow-reset">
                    <div class="sparkline8-hd">
                        <div class="main-sparkline8-hd">
                            <h1>Employee List</h1>
                           
                        </div>
                    </div>
                    <div class="sparkline8-graph">
                        <div class="datatable-dashv1-list custom-datatable-overright">
                            <div id="toolbar">
                                <select class="form-control">
                                    <option value="">Export Basic</option>
                                    <option value="all">Export All</option>
                                    <option value="selected">Export Selected</option>
                                </select>
                            </div>
                            <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                <thead>
                                    <tr>
                                        <th data-field="state" data-checkbox="true"></th>
                                        <th data-field="id">ID</th>
                                        <th data-field="Title"> Name</th>
                                        <th data-field="email">Email</th>
                                        <th data-field="mobile">Mobile </th>
                                        <th data-field="location">Location</th>
                                        <th data-field="action">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                   <?php  $i=1;?>
                                   <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                    <td></td>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td> <?php echo e($user->email); ?></td> 
                                    <td> <?php echo e($user->mobile_no); ?></td> 
                                    <td> <?php echo e($user->location); ?></td> 
                                    <td><a href="<?php echo url('admin/edit-employee').'/'. base64_encode($user->id) ; ?>"><i class="fa fa-edit"></i></a>
                                     <button type="button" class="delete" data-toggle="modal" data-id="<?php echo e($user->id); ?>" data-target="#id01">
  <i class="fa fa-trash" ></i>
</button>
</td> 
                                </tr>
                                <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                           
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?> 

<script type="text/javascript">
     $(document).on('click', '.delete', function(e) {

        e.preventDefault();

        const id = $(this).data('id');
      
      document.getElementById('del_id').value = id;
    })
</script>

<!-- The Modal -->
<div class="modal" id="id01">
  <div class="modal-dialog">
    <form action="<?php echo e(url('admin/delete-employee')); ?>" method="POST">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Delete </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <input type="hidden" name="del_id" id="del_id">
        Are you sure ! you want to delete this?
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
         <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
          <button type="submit" class="btn btn-success" >Delete</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
</form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.webapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\softlab\resources\views/admin/UserList.blade.php ENDPATH**/ ?>