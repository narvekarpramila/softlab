  <div class="left-sidebar-pro">
    <nav id="sidebar">
        <div class="sidebar-header">
            <a href="#"><img src="<?php echo e(asset('public/admin/img/message/1.jpg')); ?>" alt="" />
            </a>
            <h3><?php echo e(Auth::user()->name); ?></h3>
        </div>
        <div class="left-custom-menu-adp-wrap">
            <ul class="nav navbar-nav left-sidebar-menu-pro">
                <li class="nav-item">                             
                    <a href="<?php echo e(url('home')); ?>"><i class="fa big-icon fa-home"></i> <span class="mini-dn">Home</span> </i></span></a>                                           

                </li>
                  <li class="nav-item">                             
                    <a href="<?php echo e(url('admin/view-employee')); ?>"><i class="fa big-icon fa-user"></i> <span class="mini-dn">Employee List</span> </i></span></a>                                           

                </li>
               
                
            </ul>
        </div>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\softlab\resources\views/layouts/admin/webapp_sidebar.blade.php ENDPATH**/ ?>