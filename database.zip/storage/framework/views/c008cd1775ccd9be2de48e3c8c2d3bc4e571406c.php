

<?php $__env->startSection('title', env('APP_NAME').' - Dashboard'); ?>

<?php $__env->startSection('header_styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
<!-- Breadcome start-->
<div class="breadcome-area mg-b-30 small-dn">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <div class="breadcome-heading">
                                <form role="search" class="">
                                    <input type="text" placeholder="Search..." class="form-control">
                                    <a href=""><i class="fa fa-search"></i></a>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                            <ul class="breadcome-menu">
                                <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                </li>
                                <li><span class="bread-blod">Dashboard</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcome End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.webapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\softlab\resources\views/admin/adminDashboard.blade.php ENDPATH**/ ?>